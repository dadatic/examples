﻿*****************************************************************************
* Collection: DIGCLASS-BIAS
* Data: Teacher's Bias in Assessments Experiment
* Code: Replication of data cleaning and preparation
* Data Processor & Controller: Carlos J. Gil Hernández
* Project: JRC-CAS-DIGCLASS - S4-Unit
* Contact: JRC-CAS-DIGCLASS@ec.europa.eu; (from June 2024: carjgil@gmail.com)
* Last Data Update: 09/11/2023
* Software: Open source .csv .txt / STATA/MP 17 (.do .dta files)
*****************************************************************************

* Here you can find the replication dofile in STATA format in the "code" folder and the raw and working datasets (including the codebook)
  of the teacher's bias in assessment experiment in the "data" folder:

 1. "code/datacleaning.do" contains all the data cleaning and preparation procedures from the raw anonymized Qualtrics data 
     where we applied the survey experiment (see "data" folder .dta or .csv files named "raw_dataset_anonymized") to set a 
     working dataset ready to be analyzed. If you do not have access to STATA software, you can check the code in the .txt file "code/datacleaning.txt".

 2. The folder "data" contains the data files named "raw_dataset_anonymized" and "cleandataset" in .dta (data/STATA) or .csv (data/CSV) 
    format on the raw and working data, respectively, to replicate the findings of the teacher's bias in assessments project or 
    run your own analyses. If you do not have access to STATA software, you can check the variables labels 
    of the "cleandataset" in the "data/codebook_cleandataset" Excel file. The updated code to replicate the related published findings 
    is available here: https://github.com/carjgil